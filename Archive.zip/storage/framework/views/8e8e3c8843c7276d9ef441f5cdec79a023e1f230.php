<style media="screen">
  table {
    width: 100%;
  }

  th, td {
      padding: 15px;
      text-align: left;
      border-bottom: 1px solid #ddd;
  }

  tr:hover {background-color: #f5f5f5;}
</style>
<?php $__env->startSection('content'); ?>
  <div class="container">
    <h1>
      Sales  <a href="<?php echo e(url('sales/create')); ?>" class="btn btn-success">+</a>
    </h1>
    <table>
      <thead>
        <tr>
          <th scope="col">Product</th>
          <th scope="col">Qty</th>
          <th scope="col">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td data-label="pID"> <?php echo e($sale->info->name); ?> </td>
            <td data-label="qty"><?php echo e($sale->quantitySold); ?></td>
            <td>
              <a href="<?php echo e(route('sales.edit', $sale->id)); ?>" class="btn btn-info">Edit</a>
              <form class="" action="<?php echo e(route('sales.destroy', $sale->id)); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('DELETE')); ?>

                <button class="btn btn-sm btn-danger">Delete</a>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>