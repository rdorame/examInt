<?php $__env->startSection('content'); ?>

            <?php if(Route::has('login')): ?>
              <?php if(auth()->guard()->check()): ?>
                <div class="content">

                </div>

              <?php else: ?>
                <div class="content">
                    <div class="title m-b-md">
                        Warehouse Admin
                    </div>

                    <div class="links">
                        <p>Log in into your account or create a new one</p>
                    </div>
                </div>

              <?php endif; ?>
            <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>