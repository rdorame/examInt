<style media="screen">
  table {
    width: 100%;
  }

  th, td {
      padding: 15px;
      text-align: left;
      border-bottom: 1px solid #ddd;
  }

  tr:hover {background-color: #f5f5f5;}
</style>
<?php $__env->startSection('content'); ?>
  <div class="container">
    <h1>
      Warehouses <a href="<?php echo e(url('warehouses/create')); ?>" class="btn btn-success">+</a>
    </h1>
    <table>
      <thead>
        <tr>
          <th scope="col">Name</th>
          <th scope="col">Min Qty</th>
          <th scope="col">Max Qty</th>
          <th scope="col">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td data-label="responsable"> <?php echo e($warehouse->name); ?> </td>
            <td data-label="client"><?php echo e($warehouse->min); ?></td>
            <td data-label="st"><?php echo e($warehouse->max); ?></td>
            <td>
              <a href="<?php echo e(route('warehouses.edit', $warehouse->id)); ?>" class="btn btn-info">Edit</a>
              <form class="" action="<?php echo e(route('warehouses.destroy', $warehouse->id)); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('DELETE')); ?>

                <button class="btn btn-sm btn-danger">Delete</a>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>