<style media="screen">
  table {
    width: 100%;
  }

  th, td {
      padding: 15px;
      text-align: left;
      border-bottom: 1px solid #ddd;
  }

  tr:hover {background-color: #f5f5f5;}
</style>
<?php $__env->startSection('content'); ?>
  <div class="container">
    <h1>
      Products <a href="<?php echo e(url('products/create')); ?>" class="btn btn-success">+</a>
    </h1>
    <table>
      <thead>
        <tr>
          <th scope="col">Name</th>
          <th scope="col">Warehouse</th>
          <th scope="col">Min Qty</th>
          <th scope="col">Max Qty</th>
          <th scope="col">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td data-label="responsable"> <?php echo e($product->name); ?> </td>
            <td data-label="client"><?php echo e($product->info->name); ?></td>
            <td data-label="responsable"> <?php echo e($product->min); ?> </td>
            <td data-label="responsable"> <?php echo e($product->max); ?> </td>
            <td>
              <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-info">Edit</a>
              <form class="" action="<?php echo e(route('products.destroy', $product->id)); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('DELETE')); ?>

                <button class="btn btn-sm btn-danger">Delete</a>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>