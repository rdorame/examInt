<?php $__env->startSection('content'); ?>

  <div class="container">
    <div class="row">
    <div class="col-md-9">
      <h1>Edit Stock</h1>
          <div class="row">
            <div class="container">
              <form class="" action="<?php echo e(route('stocks.update', $stock->id)); ?>" method="post" enctype="multipart/form-data">
                  <?php echo e(csrf_field()); ?>

                  <?php echo e(method_field('put')); ?>

                  <br>
                  <div class="form-group">
                    <label for="min">Product: </label>
                    <?php echo e($stock->productID); ?>

                  </div>
                  <div class="form-group">
                    <label for="name">Qty to store: </label>
                    <input type="text" name="qty" value="<?php echo e($stock->quantityStored); ?>">
                  </div>
                  <br>

                  <button type="submit" name="button" class="btn btn-success">Submit</button>
              </form>

            </div>
          </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>