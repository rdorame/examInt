<style media="screen">
  table {
    width: 100%;
  }

  th, td {
      padding: 15px;
      text-align: left;
      border-bottom: 1px solid #ddd;
  }

  tr:hover {background-color: #f5f5f5;}
</style>
<?php $__env->startSection('content'); ?>
  <div class="container">
    <h1>
      Stock <a href="<?php echo e(url('stocks/create')); ?>" class="btn btn-success">+</a>
    </h1>
    <table>
      <thead>
        <tr>
          <th scope="col">Product</th>
          <th scope="col">Qty</th>
          <th scope="col">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td data-label="responsable"> <?php echo e($stock->info->name); ?> </td>
            <td data-label="client"><?php echo e($stock->quantityStored); ?></td>
            <td>
              <a href="<?php echo e(route('stocks.edit', $stock->id)); ?>" class="btn btn-info">Edit</a>
              <form class="" action="<?php echo e(route('stocks.destroy', $stock->id)); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('DELETE')); ?>

                <button class="btn btn-sm btn-danger">Delete</a>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>